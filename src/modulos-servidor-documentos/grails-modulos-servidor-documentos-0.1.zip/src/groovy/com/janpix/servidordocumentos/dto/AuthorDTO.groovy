package com.janpix.servidordocumentos.dto

class AuthorDTO {
	String oidHealthEntity
	String authorPerson
	String authorRole
	String authorSpecialty
}
